﻿#######
#
function Download-File
{
    param(
        [string] $urlToDownload,
        [string[]] $FolderPath,
		[string] $FileName,
        [int] $maxAttempts = 3,
		[switch] $verbose
		)
    if($verbose)
    {
        $VerbosePreference = "continue"
    }

    #create the folder if not exist
    if(!(Test-Path $FolderPath))
    {
        New-Item -ItemType Directory -Path $FolderPath -Force
    }

    $filePath = "$FolderPath\$FileName"
    
    $attemptSeq=0
    while (!(Test-Path $filePath) -and ($attemptSeq -lt $maxAttempts))
    {
        try
        {
            Write-Verbose -Message "Downloading file(attempt:$attemptSeq) from $urlToDownload to $FolderPath...."
			wget -Uri $urlToDownload -OutFile "$FolderPath\$FileName" 
        }
        catch
        {
            Write-Verbose "Exception occured while downloading in attempt:$attemptSeq . Exp->$_.Exception.Message"

            $errorMsg = "$errorMsg ; Attempt:$attemptSeq -> $_.Exception.Message"
        }
        Write-Verbose "sleeping for 2 seconds"
        sleep 2
        $attemptSeq = $attemptSeq + 1
    }
    if(Test-Path $FolderPath)
    {
        return $true
    }
    else
    {
        throw "Error occured while downloading the file. Exp->$errorMsg"
    }
}

export-modulemember -function Download-File